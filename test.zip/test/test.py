import tkinter as tk

a=tk.Label(text="Your device is being hacked")
a.pack()
b=tk.Button(text="Ok")
b.pack()

tk.mainloop()